import { useState, useEffect } from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import { Navigation } from "./components/Navigation"
import { LandingPage } from "./components/LandingPage"
import { AnalyticsPage } from "./components/pages/AnalyticsPage"
import { SchedulesPage } from "./components/pages/SchedulesPage"
import { InsightsPage } from "./components/pages/InsightsPage"
import { toast } from "sonner@2.0.3"

// Mock data types
interface KPIData {
  avgDelay: number
  throughput: number
  utilization: number
  onTimePerformance: number
}

interface TrainSchedule {
  id: string
  name: string
  type: 'express' | 'freight' | 'local'
  startTime: string
  endTime: string
  status: 'on-time' | 'delayed' | 'cancelled'
  delay?: number
  route: string
}

interface Recommendation {
  id: string
  type: 'priority' | 'reroute' | 'delay' | 'info'
  title: string
  description: string
  impact: 'high' | 'medium' | 'low'
  timestamp: string
}

interface Station {
  id: string
  name: string
  x: number
  y: number
  status: 'normal' | 'congested' | 'blocked'
}

interface Track {
  from: string
  to: string
  status: 'normal' | 'delayed' | 'blocked'
}

export default function App() {
  // State for disruption controls
  const [selectedTrain, setSelectedTrain] = useState("")
  const [selectedSection, setSelectedSection] = useState("")
  const [selectedStation, setSelectedStation] = useState("")
  const [delayMinutes, setDelayMinutes] = useState([15])
  const [isUpdating, setIsUpdating] = useState(false)

  // Mock data state
  const [kpiData, setKpiData] = useState<KPIData>({
    avgDelay: 3,
    throughput: 24,
    utilization: 78,
    onTimePerformance: 92
  })

  const [trainSchedules, setTrainSchedules] = useState<TrainSchedule[]>([
    {
      id: "EXP-101",
      name: "Mumbai Express",
      type: "express",
      startTime: "08:30",
      endTime: "14:45",
      status: "on-time",
      route: "Mumbai → Delhi"
    },
    {
      id: "FRG-201",
      name: "Freight Express",
      type: "freight",
      startTime: "10:15",
      endTime: "18:30",
      status: "delayed",
      delay: 12,
      route: "Pune → Chennai"
    },
    {
      id: "EXP-102",
      name: "Shatabdi Express",
      type: "express",
      startTime: "12:00",
      endTime: "16:30",
      status: "on-time",
      route: "Delhi → Agra"
    },
    {
      id: "LOC-301",
      name: "Local Passenger",
      type: "local",
      startTime: "15:45",
      endTime: "19:15",
      status: "on-time",
      route: "Mumbai → Pune"
    },
    {
      id: "FRG-202",
      name: "Cargo Special",
      type: "freight",
      startTime: "20:00",
      endTime: "21:45",
      status: "delayed",
      delay: 8,
      route: "Chennai → Bangalore"
    }
  ])

  const [recommendations, setRecommendations] = useState<Recommendation[]>([
    {
      id: "rec-1",
      type: "priority",
      title: "Priority Override Applied",
      description: "Train EXP-101 given precedence over Train FRG-201 due to passenger priority and schedule efficiency.",
      impact: "medium",
      timestamp: "2 minutes ago"
    },
    {
      id: "rec-2",
      type: "reroute",
      title: "Section Optimization",
      description: "Section A-B showing high utilization. Rerouting freight traffic through alternate path to reduce congestion.",
      impact: "low",
      timestamp: "5 minutes ago"
    }
  ])

  const [stations] = useState<Station[]>([
    { id: "A", name: "Mumbai", x: 50, y: 100, status: "normal" },
    { id: "B", name: "Pune", x: 150, y: 80, status: "congested" },
    { id: "C", name: "Delhi", x: 250, y: 60, status: "normal" },
    { id: "D", name: "Chennai", x: 350, y: 120, status: "normal" }
  ])

  const [tracks] = useState<Track[]>([
    { from: "A", to: "B", status: "delayed" },
    { from: "B", to: "C", status: "normal" },
    { from: "C", to: "D", status: "normal" },
    { from: "A", to: "C", status: "normal" }
  ])

  // Simulation function to update KPIs periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setKpiData(prev => ({
        avgDelay: Math.max(0, prev.avgDelay + (Math.random() - 0.5) * 2),
        throughput: Math.max(15, Math.min(30, prev.throughput + (Math.random() - 0.5) * 2)),
        utilization: Math.max(60, Math.min(95, prev.utilization + (Math.random() - 0.5) * 5)),
        onTimePerformance: Math.max(80, Math.min(98, prev.onTimePerformance + (Math.random() - 0.5) * 3))
      }))
    }, 10000) // Update every 10 seconds

    return () => clearInterval(interval)
  }, [])

  const handleReset = () => {
    setSelectedTrain("")
    setSelectedSection("")
    setSelectedStation("")
    setDelayMinutes([15])
    setIsUpdating(true)
    
    // Reset to initial values
    setKpiData({
      avgDelay: 3,
      throughput: 24,
      utilization: 78,
      onTimePerformance: 92
    })

    // Reset train schedules
    setTrainSchedules(prev => prev.map(train => ({
      ...train,
      status: 'on-time' as const,
      delay: undefined
    })))

    setRecommendations([])
    
    setTimeout(() => setIsUpdating(false), 600)
    toast.success("Dashboard reset successfully")
  }

  const simulateAIOptimization = (action: string, target?: string) => {
    setIsUpdating(true)
    
    // Simulate AI processing delay
    setTimeout(() => {
      const timestamp = new Date().toLocaleTimeString()
      let newRecommendation: Recommendation

      switch (action) {
        case "delay":
          newRecommendation = {
            id: `rec-${Date.now()}`,
            type: "delay",
            title: `Train ${target} Delayed`,
            description: `Applied ${delayMinutes[0]}-minute delay to ${target}. System is recalculating optimal schedules for downstream traffic.`,
            impact: "medium",
            timestamp: "Just now"
          }
          
          // Update the train schedule
          setTrainSchedules(prev => prev.map(train => 
            train.id === target 
              ? { ...train, status: 'delayed' as const, delay: delayMinutes[0] }
              : train
          ))
          
          // Update KPIs
          setKpiData(prev => ({
            ...prev,
            avgDelay: prev.avgDelay + 2,
            onTimePerformance: Math.max(80, prev.onTimePerformance - 3)
          }))
          break

        case "block":
          newRecommendation = {
            id: `rec-${Date.now()}`,
            type: "reroute",
            title: `Section ${target} Blocked`,
            description: `Section ${target} temporarily blocked. AI has initiated automatic rerouting for affected trains to minimize delays.`,
            impact: "high",
            timestamp: "Just now"
          }
          
          setKpiData(prev => ({
            ...prev,
            utilization: Math.min(95, prev.utilization + 8),
            avgDelay: prev.avgDelay + 4
          }))
          break

        case "reschedule":
          newRecommendation = {
            id: `rec-${Date.now()}`,
            type: "priority",
            title: `Train ${target} Rescheduled`,
            description: `Successfully rescheduled ${target} to optimize network efficiency. Adjusted departure time to reduce system-wide delays.`,
            impact: "low",
            timestamp: "Just now"
          }
          
          setKpiData(prev => ({
            ...prev,
            avgDelay: Math.max(0, prev.avgDelay - 1),
            onTimePerformance: Math.min(98, prev.onTimePerformance + 2)
          }))
          break

        default:
          return
      }

      setRecommendations(prev => [newRecommendation, ...prev].slice(0, 5))
      setIsUpdating(false)
      toast.success("AI optimization complete")
    }, 1500)
  }

  const handleDelayTrain = () => {
    if (!selectedTrain) {
      toast.error("Please select a train first")
      return
    }
    simulateAIOptimization("delay", selectedTrain)
  }

  const handleBlockSection = () => {
    if (!selectedSection) {
      toast.error("Please select a section first")
      return
    }
    simulateAIOptimization("block", selectedSection)
  }

  const handleRescheduleTrain = () => {
    if (!selectedTrain) {
      toast.error("Please select a train first")
      return
    }
    simulateAIOptimization("reschedule", selectedTrain)
  }

  return (
    <Router>
      <div className="min-h-screen">
        <Navigation onReset={handleReset} />
        
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/preview_page.html" element={<LandingPage />} />
          <Route 
            path="/analytics" 
            element={
              <AnalyticsPage
                kpiData={kpiData}
                isUpdating={isUpdating}
                selectedTrain={selectedTrain}
                selectedSection={selectedSection}
                selectedStation={selectedStation}
                delayMinutes={delayMinutes}
                onTrainChange={setSelectedTrain}
                onSectionChange={setSelectedSection}
                onStationChange={setSelectedStation}
                onDelayChange={setDelayMinutes}
                onDelayTrain={handleDelayTrain}
                onBlockSection={handleBlockSection}
                onRescheduleTrain={handleRescheduleTrain}
              />
            } 
          />
          <Route 
            path="/schedules" 
            element={
              <SchedulesPage
                trainSchedules={trainSchedules}
                selectedTrain={selectedTrain}
                selectedSection={selectedSection}
                selectedStation={selectedStation}
                delayMinutes={delayMinutes}
                onTrainChange={setSelectedTrain}
                onSectionChange={setSelectedSection}
                onStationChange={setSelectedStation}
                onDelayChange={setDelayMinutes}
                onDelayTrain={handleDelayTrain}
                onBlockSection={handleBlockSection}
                onRescheduleTrain={handleRescheduleTrain}
              />
            } 
          />
          <Route 
            path="/insights" 
            element={
              <InsightsPage
                recommendations={recommendations}
                stations={stations}
                tracks={tracks}
                selectedTrain={selectedTrain}
                selectedSection={selectedSection}
                selectedStation={selectedStation}
                delayMinutes={delayMinutes}
                onTrainChange={setSelectedTrain}
                onSectionChange={setSelectedSection}
                onStationChange={setSelectedStation}
                onDelayChange={setDelayMinutes}
                onDelayTrain={handleDelayTrain}
                onBlockSection={handleBlockSection}
                onRescheduleTrain={handleRescheduleTrain}
              />
            } 
          />
          {/* Catch-all route for any unmatched paths */}
          <Route path="*" element={<LandingPage />} />
        </Routes>
      </div>
    </Router>
  )
}