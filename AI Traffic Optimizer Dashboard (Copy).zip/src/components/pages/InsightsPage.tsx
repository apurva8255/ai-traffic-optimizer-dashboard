import { RecommendationPanel } from "../RecommendationPanel"
import { StationMap } from "../StationMap"
import { DisruptionSidebar } from "../DisruptionSidebar"

interface Recommendation {
  id: string
  type: 'priority' | 'reroute' | 'delay' | 'info'
  title: string
  description: string
  impact: 'high' | 'medium' | 'low'
  timestamp: string
}

interface Station {
  id: string
  name: string
  x: number
  y: number
  status: 'normal' | 'congested' | 'blocked'
}

interface Track {
  from: string
  to: string
  status: 'normal' | 'delayed' | 'blocked'
}

interface InsightsPageProps {
  recommendations: Recommendation[]
  stations: Station[]
  tracks: Track[]
  selectedTrain: string
  selectedSection: string
  selectedStation: string
  delayMinutes: number[]
  onTrainChange: (value: string) => void
  onSectionChange: (value: string) => void
  onStationChange: (value: string) => void
  onDelayChange: (value: number[]) => void
  onDelayTrain: () => void
  onBlockSection: () => void
  onRescheduleTrain: () => void
}

export function InsightsPage({
  recommendations,
  stations,
  tracks,
  selectedTrain,
  selectedSection,
  selectedStation,
  delayMinutes,
  onTrainChange,
  onSectionChange,
  onStationChange,
  onDelayChange,
  onDelayTrain,
  onBlockSection,
  onRescheduleTrain
}: InsightsPageProps) {
  const highImpactRecs = recommendations.filter(rec => rec.impact === 'high').length
  const mediumImpactRecs = recommendations.filter(rec => rec.impact === 'medium').length
  const lowImpactRecs = recommendations.filter(rec => rec.impact === 'low').length

  const normalStations = stations.filter(station => station.status === 'normal').length
  const alertStations = stations.filter(station => station.status !== 'normal').length

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <DisruptionSidebar
        selectedTrain={selectedTrain}
        selectedSection={selectedSection}
        selectedStation={selectedStation}
        delayMinutes={delayMinutes}
        onTrainChange={onTrainChange}
        onSectionChange={onSectionChange}
        onStationChange={onStationChange}
        onDelayChange={onDelayChange}
        onDelayTrain={onDelayTrain}
        onBlockSection={onBlockSection}
        onRescheduleTrain={onRescheduleTrain}
      />
      
      <main className="flex-1 p-8 lg:p-12 space-y-10">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-3">
            <div className="w-2 h-8 bg-gradient-to-b from-purple-500 to-purple-700 rounded-full"></div>
            <h1 className="text-4xl font-bold text-gray-800">AI-Powered Insights & Network Status</h1>
          </div>
          <p className="text-gray-600 text-xl ml-6">
            Intelligent recommendations and network visualization for optimal traffic flow management
          </p>
        </div>

        {/* AI Insights Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-red-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-600 font-semibold mb-1">High Priority</p>
                <p className="text-3xl font-bold text-red-700">{highImpactRecs}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">🔥</span>
              </div>
            </div>
            <p className="text-sm text-red-600 mt-2">Critical recommendations</p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-orange-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-600 font-semibold mb-1">Medium Priority</p>
                <p className="text-3xl font-bold text-orange-700">{mediumImpactRecs}</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">⚡</span>
              </div>
            </div>
            <p className="text-sm text-orange-600 mt-2">Important optimizations</p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-green-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 font-semibold mb-1">Low Priority</p>
                <p className="text-3xl font-bold text-green-700">{lowImpactRecs}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">✓</span>
              </div>
            </div>
            <p className="text-sm text-green-600 mt-2">Minor improvements</p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-blue-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 font-semibold mb-1">Network Health</p>
                <p className="text-3xl font-bold text-blue-700">{Math.round((normalStations / stations.length) * 100)}%</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">🗺️</span>
              </div>
            </div>
            <p className="text-sm text-blue-600 mt-2">Stations operating normally</p>
          </div>
        </div>

        {/* Main Insights Content */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <RecommendationPanel recommendations={recommendations} />
          <StationMap stations={stations} tracks={tracks} />
        </div>

        {/* AI Intelligence Overview */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-gray-200 p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-lg">🤖</span>
            </div>
            AI Intelligence Overview
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                <span className="text-lg">📊</span>
                Predictive Analytics
              </h4>
              <div className="space-y-3">
                <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                  <p className="font-semibold text-blue-800 mb-1">Traffic Pattern Analysis</p>
                  <p className="text-sm text-blue-600">AI continuously monitors traffic flows to predict congestion points 15-30 minutes in advance.</p>
                </div>
                <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
                  <p className="font-semibold text-green-800 mb-1">Delay Prediction Model</p>
                  <p className="text-sm text-green-600">Machine learning algorithms predict potential delays with 94% accuracy based on historical data.</p>
                </div>
                <div className="p-4 bg-gradient-to-r from-purple-50 to-violet-50 rounded-lg border border-purple-200">
                  <p className="font-semibold text-purple-800 mb-1">Route Optimization</p>
                  <p className="text-sm text-purple-600">Dynamic routing algorithms suggest optimal paths to minimize system-wide delays.</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                <span className="text-lg">⚙️</span>
                Optimization Strategies
              </h4>
              <div className="space-y-3">
                <div className="p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-lg border border-orange-200">
                  <p className="font-semibold text-orange-800 mb-1">Priority-Based Scheduling</p>
                  <p className="text-sm text-orange-600">Express passenger trains receive automatic priority during high-traffic periods.</p>
                </div>
                <div className="p-4 bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg border border-teal-200">
                  <p className="font-semibold text-teal-800 mb-1">Dynamic Load Balancing</p>
                  <p className="text-sm text-teal-600">Freight traffic is automatically redistributed to less congested routes during peak hours.</p>
                </div>
                <div className="p-4 bg-gradient-to-r from-yellow-50 to-amber-50 rounded-lg border border-yellow-200">
                  <p className="font-semibold text-yellow-800 mb-1">Proactive Maintenance</p>
                  <p className="text-sm text-yellow-600">AI schedules maintenance windows to minimize disruption to passenger services.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}