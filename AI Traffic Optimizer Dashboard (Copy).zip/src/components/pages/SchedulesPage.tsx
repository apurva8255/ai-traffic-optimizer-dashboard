import { TrainTimeline } from "../TrainTimeline"
import { DisruptionSidebar } from "../DisruptionSidebar"

interface TrainSchedule {
  id: string
  name: string
  type: 'express' | 'freight' | 'local'
  startTime: string
  endTime: string
  status: 'on-time' | 'delayed' | 'cancelled'
  delay?: number
  route: string
}

interface SchedulesPageProps {
  trainSchedules: TrainSchedule[]
  selectedTrain: string
  selectedSection: string
  selectedStation: string
  delayMinutes: number[]
  onTrainChange: (value: string) => void
  onSectionChange: (value: string) => void
  onStationChange: (value: string) => void
  onDelayChange: (value: number[]) => void
  onDelayTrain: () => void
  onBlockSection: () => void
  onRescheduleTrain: () => void
}

export function SchedulesPage({
  trainSchedules,
  selectedTrain,
  selectedSection,
  selectedStation,
  delayMinutes,
  onTrainChange,
  onSectionChange,
  onStationChange,
  onDelayChange,
  onDelayTrain,
  onBlockSection,
  onRescheduleTrain
}: SchedulesPageProps) {
  const onTimeTrains = trainSchedules.filter(train => train.status === 'on-time').length
  const delayedTrains = trainSchedules.filter(train => train.status === 'delayed').length
  const totalTrains = trainSchedules.length

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <DisruptionSidebar
        selectedTrain={selectedTrain}
        selectedSection={selectedSection}
        selectedStation={selectedStation}
        delayMinutes={delayMinutes}
        onTrainChange={onTrainChange}
        onSectionChange={onSectionChange}
        onStationChange={onStationChange}
        onDelayChange={onDelayChange}
        onDelayTrain={onDelayTrain}
        onBlockSection={onBlockSection}
        onRescheduleTrain={onRescheduleTrain}
      />
      
      <main className="flex-1 p-8 lg:p-12 space-y-10">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-3">
            <div className="w-2 h-8 bg-gradient-to-b from-[#E63946] to-[#ff6b7a] rounded-full"></div>
            <h1 className="text-4xl font-bold text-gray-800">Train Schedule Management</h1>
          </div>
          <p className="text-gray-600 text-xl ml-6">
            Track real-time train movements and schedule adherence across the entire network
          </p>
        </div>

        {/* Schedule Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-green-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 font-semibold mb-1">On Schedule</p>
                <p className="text-3xl font-bold text-green-700">{onTimeTrains}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">✅</span>
              </div>
            </div>
            <p className="text-sm text-green-600 mt-2">
              {Math.round((onTimeTrains / totalTrains) * 100)}% of total trains
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-red-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-600 font-semibold mb-1">Delayed</p>
                <p className="text-3xl font-bold text-red-700">{delayedTrains}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">⚠️</span>
              </div>
            </div>
            <p className="text-sm text-red-600 mt-2">
              {Math.round((delayedTrains / totalTrains) * 100)}% of total trains
            </p>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-blue-200 p-6 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 font-semibold mb-1">Total Active</p>
                <p className="text-3xl font-bold text-blue-700">{totalTrains}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">🚅</span>
              </div>
            </div>
            <p className="text-sm text-blue-600 mt-2">
              Trains currently monitored
            </p>
          </div>
        </div>
        
        <TrainTimeline schedules={trainSchedules} />

        {/* Schedule Analysis */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-gray-200 p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">Schedule Analysis & Insights</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-700">Route Performance</h4>
              <div className="space-y-3">
                {[
                  { route: "Mumbai → Delhi", performance: 95, color: "green" },
                  { route: "Pune → Chennai", performance: 87, color: "yellow" },
                  { route: "Delhi → Agra", performance: 98, color: "green" },
                  { route: "Chennai → Bangalore", performance: 82, color: "orange" }
                ].map((route, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-700">{route.route}</span>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${
                        route.color === 'green' ? 'bg-green-500' :
                        route.color === 'yellow' ? 'bg-yellow-500' :
                        'bg-orange-500'
                      }`}></div>
                      <span className="font-bold text-gray-800">{route.performance}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-700">Service Type Distribution</h4>
              <div className="space-y-3">
                {[
                  { type: "Express Services", count: 2, icon: "🚅", color: "blue" },
                  { type: "Freight Services", count: 2, icon: "🚂", color: "green" },
                  { type: "Local Services", count: 1, icon: "🚃", color: "orange" }
                ].map((service, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{service.icon}</span>
                      <span className="font-medium text-gray-700">{service.type}</span>
                    </div>
                    <span className="font-bold text-gray-800">{service.count} trains</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}