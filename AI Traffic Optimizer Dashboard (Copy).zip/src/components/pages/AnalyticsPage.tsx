import { KPICards } from "../KPICards"
import { DisruptionSidebar } from "../DisruptionSidebar"

interface KPIData {
  avgDelay: number
  throughput: number
  utilization: number
  onTimePerformance: number
}

interface AnalyticsPageProps {
  kpiData: KPIData
  isUpdating: boolean
  selectedTrain: string
  selectedSection: string
  selectedStation: string
  delayMinutes: number[]
  onTrainChange: (value: string) => void
  onSectionChange: (value: string) => void
  onStationChange: (value: string) => void
  onDelayChange: (value: number[]) => void
  onDelayTrain: () => void
  onBlockSection: () => void
  onRescheduleTrain: () => void
}

export function AnalyticsPage({
  kpiData,
  isUpdating,
  selectedTrain,
  selectedSection,
  selectedStation,
  delayMinutes,
  onTrainChange,
  onSectionChange,
  onStationChange,
  onDelayChange,
  onDelayTrain,
  onBlockSection,
  onRescheduleTrain
}: AnalyticsPageProps) {
  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <DisruptionSidebar
        selectedTrain={selectedTrain}
        selectedSection={selectedSection}
        selectedStation={selectedStation}
        delayMinutes={delayMinutes}
        onTrainChange={onTrainChange}
        onSectionChange={onSectionChange}
        onStationChange={onStationChange}
        onDelayChange={onDelayChange}
        onDelayTrain={onDelayTrain}
        onBlockSection={onBlockSection}
        onRescheduleTrain={onRescheduleTrain}
      />
      
      <main className="flex-1 p-8 lg:p-12 space-y-10">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-3">
            <div className="w-2 h-8 bg-gradient-to-b from-[#003DA5] to-[#0066cc] rounded-full"></div>
            <h1 className="text-4xl font-bold text-gray-800">Performance Analytics</h1>
          </div>
          <p className="text-gray-600 text-xl ml-6">
            Real-time insights into railway network performance and operational efficiency
          </p>
        </div>
        
        <KPICards data={kpiData} isUpdating={isUpdating} />

        {/* Additional Analytics Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-gray-200 p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Performance Trends</h3>
            <p className="text-gray-600 text-lg leading-relaxed">
              Track historical performance metrics to identify patterns and optimize operations. 
              The system continuously monitors network efficiency and provides predictive insights.
            </p>
            <div className="mt-6 space-y-3">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-semibold text-gray-700">Weekly Average Delay</span>
                <span className="text-[#003DA5] font-bold">{Math.round(kpiData.avgDelay * 1.2)} min</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-semibold text-gray-700">Peak Hour Throughput</span>
                <span className="text-[#003DA5] font-bold">{Math.round(kpiData.throughput * 1.3)}/hr</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-semibold text-gray-700">Network Reliability</span>
                <span className="text-green-600 font-bold">{Math.round(kpiData.onTimePerformance)}%</span>
              </div>
            </div>
          </div>

          <div className="bg-white/80 backdrop-blur-sm rounded-2xl border-2 border-gray-200 p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">System Health</h3>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              Monitor critical system components and network infrastructure status for proactive maintenance.
            </p>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl border border-green-200">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="font-semibold text-green-800">Signal Systems</span>
                </div>
                <span className="text-green-600 font-bold">Operational</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl border border-blue-200">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                  <span className="font-semibold text-blue-800">Communication Network</span>
                </div>
                <span className="text-blue-600 font-bold">Stable</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-xl border border-yellow-200">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                  <span className="font-semibold text-yellow-800">Track Sensors</span>
                </div>
                <span className="text-yellow-600 font-bold">Monitoring</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}