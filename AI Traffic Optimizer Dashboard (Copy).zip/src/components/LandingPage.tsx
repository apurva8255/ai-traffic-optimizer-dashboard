import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Train, Activity, Brain, MapPin, BarChart3, Zap, Shield, Clock } from "lucide-react"
import { Link } from "react-router-dom"

export function LandingPage() {
  const features = [
    {
      icon: BarChart3,
      title: "Performance Analytics",
      description: "Real-time KPI monitoring with live updates on delays, throughput, and network utilization",
      color: "from-blue-500 to-blue-600",
      path: "/analytics"
    },
    {
      icon: Clock,
      title: "Train Schedule Management",
      description: "Visual timeline tracking of all train movements with schedule adherence monitoring",
      color: "from-red-500 to-red-600", 
      path: "/schedules"
    },
    {
      icon: Brain,
      title: "AI-Powered Insights",
      description: "Intelligent recommendations and network status visualization for optimal traffic flow",
      color: "from-purple-500 to-purple-600",
      path: "/insights"
    }
  ]

  const stats = [
    { label: "Trains Monitored", value: "500+", icon: Train },
    { label: "Network Efficiency", value: "98.5%", icon: Activity },
    { label: "AI Recommendations", value: "24/7", icon: Brain },
    { label: "Stations Connected", value: "150+", icon: MapPin }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#003DA5]/10 via-transparent to-[#E63946]/10"></div>
        <div className="relative max-w-7xl mx-auto px-8 py-20">
          <div className="text-center space-y-8">
            {/* Logo and Title */}
            <div className="flex justify-center">
              <div className="relative">
                <div className="w-20 h-20 bg-gradient-to-br from-[#003DA5] to-[#0066cc] rounded-3xl flex items-center justify-center shadow-2xl">
                  <Train className="w-10 h-10 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-white animate-pulse"></div>
              </div>
            </div>

            <div className="space-y-4">
              <Badge className="bg-gradient-to-r from-[#003DA5] to-[#0066cc] text-white px-4 py-2 text-lg font-semibold">
                <Zap className="w-4 h-4 mr-2" />
                Next-Generation Railway Management
              </Badge>
              <h1 className="text-6xl font-bold text-gray-900 leading-tight">
                AI-Powered Train Traffic
                <br />
                <span className="bg-gradient-to-r from-[#003DA5] to-[#E63946] bg-clip-text text-transparent">
                  Optimization System
                </span>
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Revolutionary intelligent railway management platform that optimizes train schedules, 
                predicts disruptions, and ensures maximum network efficiency through advanced AI algorithms.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex gap-4 justify-center flex-wrap">
              <Link to="/analytics">
                <Button className="bg-gradient-to-r from-[#003DA5] to-[#0066cc] hover:from-[#002a85] hover:to-[#0052a3] text-white px-8 py-4 text-lg font-semibold shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  View Analytics Dashboard
                </Button>
              </Link>
              <Link to="/schedules">
                <Button variant="outline" className="border-2 border-[#003DA5] text-[#003DA5] hover:bg-[#003DA5] hover:text-white px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300">
                  <Clock className="w-5 h-5 mr-2" />
                  Monitor Train Schedules
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-white/50 backdrop-blur-sm border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center space-y-3">
                <div className="w-16 h-16 bg-gradient-to-br from-[#003DA5] to-[#0066cc] rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <div className="space-y-1">
                  <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm font-medium text-gray-600">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20">
        <div className="max-w-7xl mx-auto px-8">
          <div className="text-center space-y-4 mb-16">
            <Badge className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-2 text-base font-semibold">
              <Shield className="w-4 h-4 mr-2" />
              Powerful Features
            </Badge>
            <h2 className="text-4xl font-bold text-gray-900">
              Comprehensive Railway Management Suite
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Access powerful tools designed to optimize railway operations, reduce delays, 
              and improve passenger experience through intelligent automation.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Link key={index} to={feature.path} className="group block">
                <Card className="h-full bg-white/80 backdrop-blur-sm border-2 border-gray-200 hover:border-gray-300 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group-hover:bg-white">
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mx-auto shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <feature.icon className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-2xl font-bold text-gray-900 group-hover:text-[#003DA5] transition-colors">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 leading-relaxed text-lg">
                      {feature.description}
                    </p>
                    <div className="mt-6">
                      <div className="inline-flex items-center text-[#003DA5] font-semibold group-hover:gap-3 gap-2 transition-all duration-300">
                        <span>Explore Module</span>
                        <div className="w-0 group-hover:w-4 overflow-hidden transition-all duration-300">
                          <div className="w-4 h-4 bg-[#003DA5] rounded-full"></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="py-16 bg-gradient-to-r from-[#003DA5] to-[#E63946]">
        <div className="max-w-4xl mx-auto text-center px-8 space-y-6">
          <h2 className="text-4xl font-bold text-white">
            Ready to Transform Your Railway Operations?
          </h2>
          <p className="text-xl text-white/90">
            Experience the power of AI-driven railway management with real-time insights and optimization.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link to="/analytics">
              <Button className="bg-white text-[#003DA5] hover:bg-gray-100 px-8 py-4 text-lg font-semibold shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
                <Activity className="w-5 h-5 mr-2" />
                Start Monitoring Now
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}