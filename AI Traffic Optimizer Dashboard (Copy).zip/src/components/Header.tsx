import { Button } from "./ui/button"
import { RotateCcw, Train } from "lucide-react"

interface HeaderProps {
  onReset: () => void
}

export function Header({ onReset }: HeaderProps) {
  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-gray-200/80 px-8 py-6 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-5">
          <div className="relative">
            <div className="w-14 h-14 bg-gradient-to-br from-[#003DA5] to-[#0066cc] rounded-2xl flex items-center justify-center shadow-lg">
              <Train className="w-8 h-8 text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div className="space-y-1">
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">AI-Powered Train Traffic Optimizer</h1>
            <p className="text-lg text-gray-600 font-medium">Real-time intelligent railway management system</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-full border border-green-200">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-green-700">System Active</span>
          </div>
          <Button 
            variant="outline" 
            onClick={onReset}
            className="flex items-center gap-3 px-6 py-3 text-lg font-medium hover:bg-gray-50 hover:border-[#003DA5] hover:text-[#003DA5] transition-all duration-200 shadow-sm"
          >
            <RotateCcw className="w-5 h-5" />
            Reset Dashboard
          </Button>
        </div>
      </div>
    </header>
  )
}