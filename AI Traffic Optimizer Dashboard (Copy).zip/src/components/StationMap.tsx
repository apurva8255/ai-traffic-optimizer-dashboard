import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"

interface Station {
  id: string
  name: string
  x: number
  y: number
  status: 'normal' | 'congested' | 'blocked'
}

interface Track {
  from: string
  to: string
  status: 'normal' | 'delayed' | 'blocked'
}

interface StationMapProps {
  stations: Station[]
  tracks: Track[]
}

export function StationMap({ stations, tracks }: StationMapProps) {
  const getStationColor = (status: string) => {
    switch (status) {
      case 'congested': return 'fill-orange-500'
      case 'blocked': return 'fill-[#E63946]'
      default: return 'fill-[#003DA5]'
    }
  }

  const getStationGlow = (status: string) => {
    switch (status) {
      case 'congested': return 'drop-shadow-[0_0_8px_rgba(249,115,22,0.6)]'
      case 'blocked': return 'drop-shadow-[0_0_8px_rgba(230,57,70,0.6)]'
      default: return 'drop-shadow-[0_0_6px_rgba(0,61,165,0.4)]'
    }
  }

  const getTrackColor = (status: string) => {
    switch (status) {
      case 'delayed': return 'stroke-orange-500'
      case 'blocked': return 'stroke-[#E63946]'
      default: return 'stroke-gray-400'
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'congested':
        return <Badge className="bg-gradient-to-r from-orange-500 to-orange-600 text-white font-semibold shadow-md">⚠️ Congested</Badge>
      case 'blocked':
        return <Badge className="bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold shadow-md">🚫 Blocked</Badge>
      default:
        return <Badge className="bg-gradient-to-r from-green-600 to-green-700 text-white font-semibold shadow-md">✅ Normal</Badge>
    }
  }

  const getStationEmoji = () => '🚉'

  const findStation = (id: string) => stations.find(s => s.id === id)

  return (
    <Card className="shadow-lg border-2 border-green-100 bg-white/80 backdrop-blur-sm overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-green-50 to-teal-50 border-b-2 border-green-100">
        <CardTitle className="flex items-center gap-3 text-2xl font-bold text-green-800">
          <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-teal-600 rounded-xl flex items-center justify-center shadow-md">
            <span className="text-lg">🗺️</span>
          </div>
          Railway Network Status
        </CardTitle>
        <p className="text-green-700 ml-13 font-medium">
          Live station and track conditions across the network
        </p>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Enhanced network diagram */}
          <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl p-6 border-2 border-gray-200 shadow-inner">
            <div className="mb-4 text-center">
              <h4 className="font-bold text-gray-800 text-lg mb-1">Network Topology</h4>
              <p className="text-sm text-gray-600">Real-time station and track status visualization</p>
            </div>
            <svg viewBox="0 0 400 200" className="w-full h-56 bg-white rounded-xl shadow-sm border border-gray-200">
              {/* Background grid pattern */}
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#f0f0f0" strokeWidth="1"/>
                </pattern>
                
                {/* Gradient definitions for stations */}
                <radialGradient id="normalGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" style={{ stopColor: '#0066cc', stopOpacity: 1 }} />
                  <stop offset="100%" style={{ stopColor: '#003DA5', stopOpacity: 1 }} />
                </radialGradient>
                <radialGradient id="congestedGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" style={{ stopColor: '#ff8c00', stopOpacity: 1 }} />
                  <stop offset="100%" style={{ stopColor: '#f97316', stopOpacity: 1 }} />
                </radialGradient>
                <radialGradient id="blockedGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" style={{ stopColor: '#ff6b7a', stopOpacity: 1 }} />
                  <stop offset="100%" style={{ stopColor: '#E63946', stopOpacity: 1 }} />
                </radialGradient>
              </defs>
              
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Draw tracks with enhanced styling */}
              {tracks.map((track, index) => {
                const fromStation = findStation(track.from)
                const toStation = findStation(track.to)
                if (!fromStation || !toStation) return null

                return (
                  <g key={index}>
                    {/* Track shadow */}
                    <line
                      x1={fromStation.x}
                      y1={fromStation.y + 2}
                      x2={toStation.x}
                      y2={toStation.y + 2}
                      stroke="rgba(0,0,0,0.2)"
                      strokeWidth="4"
                    />
                    {/* Main track */}
                    <line
                      x1={fromStation.x}
                      y1={fromStation.y}
                      x2={toStation.x}
                      y2={toStation.y}
                      className={`${getTrackColor(track.status)} stroke-4`}
                      strokeDasharray={track.status === 'blocked' ? '10,5' : 'none'}
                    />
                    {/* Track animation for active routes */}
                    {track.status === 'normal' && (
                      <line
                        x1={fromStation.x}
                        y1={fromStation.y}
                        x2={toStation.x}
                        y2={toStation.y}
                        stroke="rgba(0,61,165,0.3)"
                        strokeWidth="2"
                        strokeDasharray="5,10"
                      >
                        <animate
                          attributeName="stroke-dashoffset"
                          values="0;15"
                          dur="2s"
                          repeatCount="indefinite"
                        />
                      </line>
                    )}
                  </g>
                )
              })}

              {/* Draw stations with enhanced styling */}
              {stations.map((station) => (
                <g key={station.id}>
                  {/* Station glow effect */}
                  <circle
                    cx={station.x}
                    cy={station.y}
                    r="16"
                    fill={station.status === 'congested' ? 'rgba(249,115,22,0.2)' : 
                          station.status === 'blocked' ? 'rgba(230,57,70,0.2)' : 
                          'rgba(0,61,165,0.2)'}
                    className="animate-pulse"
                  />
                  {/* Main station circle */}
                  <circle
                    cx={station.x}
                    cy={station.y}
                    r="10"
                    fill={station.status === 'congested' ? 'url(#congestedGradient)' :
                          station.status === 'blocked' ? 'url(#blockedGradient)' :
                          'url(#normalGradient)'}
                    stroke="white"
                    strokeWidth="3"
                    className={getStationGlow(station.status)}
                  />
                  {/* Station label */}
                  <text
                    x={station.x}
                    y={station.y - 20}
                    textAnchor="middle"
                    className="text-sm font-bold fill-gray-800"
                    style={{ textShadow: '1px 1px 2px rgba(255,255,255,0.8)' }}
                  >
                    {station.name}
                  </text>
                  {/* Station ID */}
                  <text
                    x={station.x}
                    y={station.y + 4}
                    textAnchor="middle"
                    className="text-xs font-bold fill-white"
                  >
                    {station.id}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          {/* Enhanced station status list */}
          <div className="space-y-4">
            <h4 className="font-bold text-gray-800 text-lg flex items-center gap-2">
              <span className="text-lg">🚉</span>
              Station Health Monitor
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {stations.map((station) => (
                <div key={station.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-white rounded-xl border-2 border-gray-200 shadow-sm hover:shadow-md transition-all duration-200">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{getStationEmoji()}</span>
                    <div>
                      <span className="font-bold text-gray-800">{station.name}</span>
                      <p className="text-sm text-gray-600">Station {station.id}</p>
                    </div>
                  </div>
                  {getStatusBadge(station.status)}
                </div>
              ))}
            </div>
          </div>

          {/* Enhanced legend */}
          <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-4 border-2 border-gray-200">
            <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <span className="text-lg">📊</span>
              Status Legend
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-5 h-5 bg-gradient-to-br from-[#0066cc] to-[#003DA5] rounded-full shadow-sm"></div>
                <span className="text-sm font-semibold text-gray-700">✅ Normal Operations</span>
              </div>
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-5 h-5 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full shadow-sm"></div>
                <span className="text-sm font-semibold text-gray-700">⚠️ High Traffic</span>
              </div>
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-5 h-5 bg-gradient-to-br from-[#E63946] to-red-600 rounded-full shadow-sm"></div>
                <span className="text-sm font-semibold text-gray-700">🚫 Service Blocked</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}