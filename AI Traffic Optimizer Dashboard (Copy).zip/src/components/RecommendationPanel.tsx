import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Brain, CheckCircle, AlertTriangle, Info } from "lucide-react"

interface Recommendation {
  id: string
  type: 'priority' | 'reroute' | 'delay' | 'info'
  title: string
  description: string
  impact: 'high' | 'medium' | 'low'
  timestamp: string
}

interface RecommendationPanelProps {
  recommendations: Recommendation[]
}

export function RecommendationPanel({ recommendations }: RecommendationPanelProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case 'priority': return CheckCircle
      case 'reroute': return AlertTriangle
      case 'delay': return AlertTriangle
      default: return Info
    }
  }

  const getIconColor = (type: string) => {
    switch (type) {
      case 'priority': return 'text-green-600'
      case 'reroute': return 'text-orange-600'
      case 'delay': return 'text-[#E63946]'
      default: return 'text-[#003DA5]'
    }
  }

  const getImpactBadge = (impact: string) => {
    switch (impact) {
      case 'high':
        return <Badge className="bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold">🔥 High Impact</Badge>
      case 'medium':
        return <Badge className="bg-gradient-to-r from-orange-500 to-orange-600 text-white font-semibold">⚡ Medium Impact</Badge>
      case 'low':
        return <Badge className="bg-gradient-to-r from-green-600 to-green-700 text-white font-semibold">✓ Low Impact</Badge>
      default:
        return <Badge variant="secondary" className="font-semibold">❓ Unknown</Badge>
    }
  }

  const getTypeEmoji = (type: string) => {
    switch (type) {
      case 'priority': return '⚡'
      case 'reroute': return '🔀'
      case 'delay': return '⏰'
      default: return '💡'
    }
  }

  const getBorderGradient = (type: string) => {
    switch (type) {
      case 'priority': return 'border-l-green-500 bg-gradient-to-r from-green-50 to-transparent'
      case 'reroute': return 'border-l-orange-500 bg-gradient-to-r from-orange-50 to-transparent'
      case 'delay': return 'border-l-red-500 bg-gradient-to-r from-red-50 to-transparent'
      default: return 'border-l-blue-500 bg-gradient-to-r from-blue-50 to-transparent'
    }
  }

  return (
    <Card className="shadow-lg border-2 border-purple-100 bg-white/80 backdrop-blur-sm overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b-2 border-purple-100">
        <CardTitle className="flex items-center gap-3 text-2xl font-bold text-purple-800">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-md">
            <Brain className="w-6 h-6 text-white" />
          </div>
          AI-Powered Recommendations
        </CardTitle>
        <p className="text-purple-700 ml-13 font-medium">
          Intelligent insights for optimal railway operations
        </p>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-96 overflow-y-auto">
          {recommendations.length === 0 ? (
            <div className="p-8 text-center">
              <div className="relative mb-6">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto shadow-lg">
                  <Brain className="w-10 h-10 text-purple-400" />
                </div>
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white animate-pulse"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">AI Monitoring Active</h3>
              <p className="text-gray-600 font-medium mb-1">Analyzing traffic patterns and network performance...</p>
              <p className="text-sm text-gray-500">Smart recommendations will appear here when optimizations are identified</p>
              
              <div className="flex justify-center gap-2 mt-4">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          ) : (
            <div className="space-y-0">
              {recommendations.map((rec, index) => {
                const Icon = getIcon(rec.type)
                return (
                  <div 
                    key={rec.id} 
                    className={`relative p-6 border-l-4 ${getBorderGradient(rec.type)} ${
                      index !== recommendations.length - 1 ? 'border-b-2 border-gray-100' : ''
                    } hover:shadow-md transition-all duration-200 group`}
                  >
                    {/* Subtle background animation */}
                    <div className="absolute inset-0 bg-gradient-to-r from-white/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    
                    <div className="relative flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-md ${
                        rec.type === 'priority' ? 'bg-green-100' :
                        rec.type === 'reroute' ? 'bg-orange-100' :
                        rec.type === 'delay' ? 'bg-red-100' :
                        'bg-blue-100'
                      } group-hover:scale-110 transition-transform duration-200`}>
                        <span className="text-lg">{getTypeEmoji(rec.type)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <h4 className="font-bold text-gray-900 text-lg leading-tight">{rec.title}</h4>
                          {getImpactBadge(rec.impact)}
                        </div>
                        <p className="text-base text-gray-700 leading-relaxed mb-4 font-medium">
                          {rec.description}
                        </p>
                        <div className="flex items-center gap-3">
                          <Icon className={`w-4 h-4 ${getIconColor(rec.type)}`} />
                          <span className="text-sm font-semibold text-gray-500">{rec.timestamp}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}