import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { TrendingUp, TrendingDown, Activity, Clock, Gauge, BarChart3 } from "lucide-react"
import { useState, useEffect } from "react"

interface KPIData {
  avgDelay: number
  throughput: number
  utilization: number
  onTimePerformance: number
}

interface KPICardsProps {
  data: KPIData
  isUpdating?: boolean
}

export function KPICards({ data, isUpdating = false }: KPICardsProps) {
  const [isFlipping, setIsFlipping] = useState(false)

  useEffect(() => {
    if (isUpdating) {
      setIsFlipping(true)
      const timer = setTimeout(() => setIsFlipping(false), 600)
      return () => clearTimeout(timer)
    }
  }, [isUpdating])

  const cards = [
    {
      title: "Average Delay",
      subtitle: "Network-wide delay metrics",
      value: `${Math.round(data.avgDelay)} min`,
      icon: Clock,
      trend: data.avgDelay <= 5 ? "up" : "down",
      color: data.avgDelay <= 5 ? "text-green-600" : "text-[#E63946]",
      bgGradient: data.avgDelay <= 5 ? "from-green-50 to-emerald-50" : "from-red-50 to-pink-50",
      iconBg: data.avgDelay <= 5 ? "bg-green-100" : "bg-red-100",
      borderColor: data.avgDelay <= 5 ? "border-green-200" : "border-red-200"
    },
    {
      title: "Train Throughput",
      subtitle: "Trains processed per hour",
      value: `${Math.round(data.throughput)}/hr`,
      icon: Activity,
      trend: "up",
      color: "text-[#003DA5]",
      bgGradient: "from-blue-50 to-indigo-50",
      iconBg: "bg-blue-100",
      borderColor: "border-blue-200"
    },
    {
      title: "Track Utilization",
      subtitle: "Network capacity usage",
      value: `${Math.round(data.utilization)}%`,
      icon: BarChart3,
      trend: data.utilization < 85 ? "up" : "down",
      color: data.utilization < 85 ? "text-green-600" : "text-orange-600",
      bgGradient: data.utilization < 85 ? "from-green-50 to-emerald-50" : "from-orange-50 to-yellow-50",
      iconBg: data.utilization < 85 ? "bg-green-100" : "bg-orange-100",
      borderColor: data.utilization < 85 ? "border-green-200" : "border-orange-200"
    },
    {
      title: "On-Time Performance",
      subtitle: "Schedule adherence rate",
      value: `${Math.round(data.onTimePerformance)}%`,
      icon: Gauge,
      trend: data.onTimePerformance >= 90 ? "up" : "down",
      color: data.onTimePerformance >= 90 ? "text-green-600" : "text-[#E63946]",
      bgGradient: data.onTimePerformance >= 90 ? "from-green-50 to-emerald-50" : "from-red-50 to-pink-50",
      iconBg: data.onTimePerformance >= 90 ? "bg-green-100" : "bg-red-100",
      borderColor: data.onTimePerformance >= 90 ? "border-green-200" : "border-red-200"
    }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      {cards.map((card, index) => (
        <Card 
          key={card.title} 
          className={`relative transition-all duration-300 hover:shadow-xl hover:-translate-y-1 bg-gradient-to-br ${card.bgGradient} border-2 ${card.borderColor} ${
            isFlipping ? 'animate-pulse' : ''
          } overflow-hidden group`}
        >
          {/* Subtle gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/50 to-transparent pointer-events-none" />
          
          <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-4 relative z-10">
            <div className="space-y-1">
              <CardTitle className="text-base font-bold text-gray-800 leading-tight">
                {card.title}
              </CardTitle>
              <p className="text-sm text-gray-600 font-medium">
                {card.subtitle}
              </p>
            </div>
            <div className={`p-3 rounded-xl ${card.iconBg} shadow-sm group-hover:scale-110 transition-transform duration-200`}>
              <card.icon className={`h-6 w-6 ${card.color}`} />
            </div>
          </CardHeader>
          
          <CardContent className="relative z-10">
            <div className="flex items-center justify-between">
              <div className={`text-3xl font-black ${card.color} tracking-tight`}>
                {card.value}
              </div>
              <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${
                card.trend === "up" ? "bg-green-100" : "bg-red-100"
              }`}>
                {card.trend === "up" ? (
                  <TrendingUp className="h-4 w-4 text-green-600" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-red-600" />
                )}
              </div>
            </div>
            
            {/* Status indicator */}
            <div className="mt-3 flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${
                card.trend === "up" ? "bg-green-500" : "bg-red-500"
              } ${isFlipping ? "animate-pulse" : ""}`} />
              <span className="text-xs font-semibold text-gray-600">
                {card.trend === "up" ? "Performing well" : "Needs attention"}
              </span>
            </div>
          </CardContent>
          
          {/* Subtle animation element */}
          <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${
            card.trend === "up" ? "from-green-400 to-emerald-500" : "from-red-400 to-pink-500"
          } transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left`} />
        </Card>
      ))}
    </div>
  )
}