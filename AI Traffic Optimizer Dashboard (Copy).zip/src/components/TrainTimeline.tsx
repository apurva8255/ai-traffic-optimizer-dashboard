import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"

interface TrainSchedule {
  id: string
  name: string
  type: 'express' | 'freight' | 'local'
  startTime: string
  endTime: string
  status: 'on-time' | 'delayed' | 'cancelled'
  delay?: number
  route: string
}

interface TrainTimelineProps {
  schedules: TrainSchedule[]
}

export function TrainTimeline({ schedules }: TrainTimelineProps) {
  const getStatusColor = (status: string, type: string) => {
    if (status === 'delayed') return 'bg-gradient-to-r from-[#E63946] to-[#ff6b7a]'
    if (status === 'cancelled') return 'bg-gradient-to-r from-gray-400 to-gray-500'
    
    switch (type) {
      case 'express': return 'bg-gradient-to-r from-[#003DA5] to-[#0066cc]'
      case 'freight': return 'bg-gradient-to-r from-green-600 to-green-500'
      case 'local': return 'bg-gradient-to-r from-orange-500 to-orange-400'
      default: return 'bg-gradient-to-r from-gray-500 to-gray-400'
    }
  }

  const getStatusBadge = (status: string, delay?: number) => {
    if (status === 'delayed') {
      return <Badge className="bg-[#E63946] hover:bg-[#d32f2f] text-white font-semibold">⚠️ Delayed {delay}min</Badge>
    }
    if (status === 'cancelled') {
      return <Badge variant="secondary" className="font-semibold">❌ Cancelled</Badge>
    }
    return <Badge className="bg-green-600 hover:bg-green-700 text-white font-semibold">✅ On Time</Badge>
  }

  const getTimelinePosition = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number)
    const totalMinutes = hours * 60 + minutes
    const startOfDay = 6 * 60 // 6 AM
    const endOfDay = 22 * 60 // 10 PM
    return ((totalMinutes - startOfDay) / (endOfDay - startOfDay)) * 100
  }

  const getTrainTypeIcon = (type: string) => {
    switch (type) {
      case 'express': return '🚅'
      case 'freight': return '🚂'
      case 'local': return '🚃'
      default: return '🚆'
    }
  }

  return (
    <Card className="shadow-lg border-2 border-gray-100 bg-white/80 backdrop-blur-sm">
      <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-bold text-[#003DA5] flex items-center gap-3">
            <div className="w-10 h-10 bg-[#003DA5] rounded-xl flex items-center justify-center shadow-md">
              <span className="text-lg">🚅</span>
            </div>
            Live Train Movement Tracker
          </CardTitle>
          <div className="flex items-center gap-2 text-sm font-medium text-gray-600">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span>Real-time updates</span>
          </div>
        </div>
        <p className="text-gray-600 ml-13">Monitor active trains across the network with live position tracking</p>
      </CardHeader>
      <CardContent className="p-8">
        <div className="space-y-8">
          {/* Enhanced Time ruler */}
          <div className="relative">
            <div className="h-12 bg-gradient-to-r from-gray-100 to-gray-50 rounded-xl border-2 border-gray-200 shadow-inner">
              <div className="absolute inset-0 flex justify-between items-center px-4">
                {['06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00'].map((time, index) => (
                  <div key={time} className="flex flex-col items-center">
                    <span className="text-sm font-bold text-gray-700">{time}</span>
                    <div className="w-px h-4 bg-gray-400 mt-1"></div>
                  </div>
                ))}
              </div>
            </div>
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-purple-500 rounded-t-xl"></div>
          </div>

          {/* Enhanced Train schedules */}
          <div className="space-y-6">
            {schedules.map((schedule, index) => {
              const startPos = getTimelinePosition(schedule.startTime)
              const endPos = getTimelinePosition(schedule.endTime)
              const width = endPos - startPos

              return (
                <div key={schedule.id} className="group hover:bg-gray-50 p-4 rounded-xl transition-all duration-200 border border-transparent hover:border-gray-200 hover:shadow-md">
                  {/* Train Info Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{getTrainTypeIcon(schedule.type)}</span>
                        <div>
                          <span className="text-lg font-bold text-gray-800">{schedule.id}</span>
                          <span className="text-base text-gray-600 ml-2 font-medium">{schedule.name}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-semibold text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                        {schedule.route}
                      </span>
                      {getStatusBadge(schedule.status, schedule.delay)}
                    </div>
                  </div>
                  
                  {/* Enhanced Timeline Bar */}
                  <div className="relative h-10 bg-gradient-to-r from-gray-100 to-gray-50 rounded-xl border-2 border-gray-200 shadow-inner overflow-hidden">
                    {/* Train movement bar */}
                    <div
                      className={`absolute top-1 bottom-1 rounded-lg shadow-md ${getStatusColor(schedule.status, schedule.type)} border border-white/30`}
                      style={{
                        left: `${Math.max(0, startPos)}%`,
                        width: `${Math.min(100 - Math.max(0, startPos), width)}%`
                      }}
                    />
                    
                    {/* Gradient overlay for better visual effect */}
                    <div
                      className="absolute top-1 bottom-1 rounded-lg bg-gradient-to-r from-white/30 to-transparent pointer-events-none"
                      style={{
                        left: `${Math.max(0, startPos)}%`,
                        width: `${Math.min(100 - Math.max(0, startPos), width)}%`
                      }}
                    />
                    
                    {/* Time labels */}
                    <div className="absolute inset-0 flex items-center">
                      <div className="absolute left-2 top-0 bottom-0 flex items-center">
                        <span 
                          className="text-xs font-bold text-gray-800 bg-white/90 px-2 py-1 rounded shadow-sm"
                          style={{ marginLeft: `${startPos}%` }}
                        >
                          {schedule.startTime}
                        </span>
                      </div>
                      <div className="absolute right-2 top-0 bottom-0 flex items-center">
                        <span 
                          className="text-xs font-bold text-gray-800 bg-white/90 px-2 py-1 rounded shadow-sm"
                          style={{ marginRight: `${100 - endPos}%` }}
                        >
                          {schedule.endTime}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Additional info bar */}
                  <div className="flex justify-between items-center mt-2 text-xs text-gray-500">
                    <span>Duration: {Math.round((endPos - startPos) * 16 / 100 * 60)} min</span>
                    <span className="capitalize">{schedule.type} Service</span>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Enhanced Legend */}
          <div className="bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-6 border-2 border-gray-200">
            <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-lg">📊</span>
              Service Type Legend
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-4 h-4 bg-gradient-to-r from-[#003DA5] to-[#0066cc] rounded"></div>
                <span className="text-sm font-semibold text-gray-700">🚅 Express</span>
              </div>
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-4 h-4 bg-gradient-to-r from-green-600 to-green-500 rounded"></div>
                <span className="text-sm font-semibold text-gray-700">🚂 Freight</span>
              </div>
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-4 h-4 bg-gradient-to-r from-orange-500 to-orange-400 rounded"></div>
                <span className="text-sm font-semibold text-gray-700">🚃 Local</span>
              </div>
              <div className="flex items-center gap-3 p-2 bg-white rounded-lg shadow-sm">
                <div className="w-4 h-4 bg-gradient-to-r from-[#E63946] to-[#ff6b7a] rounded"></div>
                <span className="text-sm font-semibold text-gray-700">⚠️ Delayed</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}