import { Button } from "./ui/button"
import { RotateCcw, Train, Home, BarChart3, Clock, Brain } from "lucide-react"
import { Link, useLocation } from "react-router-dom"

interface NavigationProps {
  onReset: () => void
}

export function Navigation({ onReset }: NavigationProps) {
  const location = useLocation()
  
  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/analytics", icon: BarChart3, label: "Analytics" },
    { path: "/schedules", icon: Clock, label: "Schedules" },
    { path: "/insights", icon: Brain, label: "AI Insights" }
  ]

  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-gray-200/80 px-8 py-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-8">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-[#003DA5] to-[#0066cc] rounded-xl flex items-center justify-center shadow-lg">
                <Train className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">AI Train Optimizer</h1>
              <p className="text-sm text-gray-600">Railway Management System</p>
            </div>
          </Link>

          {/* Navigation Menu */}
          <nav className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path
              return (
                <Link key={item.path} to={item.path}>
                  <Button 
                    variant={isActive ? "default" : "ghost"}
                    className={`flex items-center gap-2 px-4 py-2 transition-all duration-200 ${
                      isActive 
                        ? "bg-[#003DA5] text-white shadow-md" 
                        : "hover:bg-gray-100 text-gray-700"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </Button>
                </Link>
              )
            })}
          </nav>
        </div>
        
        <div className="flex items-center gap-4">
          {/* System Status */}
          {location.pathname !== "/" && (
            <div className="flex items-center gap-2 px-3 py-2 bg-green-50 rounded-full border border-green-200">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-medium text-green-700">System Active</span>
            </div>
          )}
          
          {/* Reset Button - only show on dashboard pages */}
          {location.pathname !== "/" && (
            <Button 
              variant="outline" 
              onClick={onReset}
              className="flex items-center gap-2 px-4 py-2 hover:bg-gray-50 hover:border-[#003DA5] hover:text-[#003DA5] transition-all duration-200 shadow-sm"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </Button>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      <nav className="md:hidden mt-4 flex gap-2 overflow-x-auto pb-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path
          return (
            <Link key={item.path} to={item.path} className="flex-shrink-0">
              <Button 
                variant={isActive ? "default" : "ghost"}
                size="sm"
                className={`flex items-center gap-2 transition-all duration-200 ${
                  isActive 
                    ? "bg-[#003DA5] text-white" 
                    : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Button>
            </Link>
          )
        })}
      </nav>
    </header>
  )
}