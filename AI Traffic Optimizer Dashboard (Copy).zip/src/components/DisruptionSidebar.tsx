import { Button } from "./ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { Slider } from "./ui/slider"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Clock, Square, Shuffle } from "lucide-react"

interface DisruptionSidebarProps {
  selectedTrain: string
  selectedSection: string
  selectedStation: string
  delayMinutes: number[]
  onTrainChange: (value: string) => void
  onSectionChange: (value: string) => void
  onStationChange: (value: string) => void
  onDelayChange: (value: number[]) => void
  onDelayTrain: () => void
  onBlockSection: () => void
  onRescheduleTrain: () => void
}

export function DisruptionSidebar({
  selectedTrain,
  selectedSection,
  selectedStation,
  delayMinutes,
  onTrainChange,
  onSectionChange,
  onStationChange,
  onDelayChange,
  onDelayTrain,
  onBlockSection,
  onRescheduleTrain
}: DisruptionSidebarProps) {
  return (
    <div className="w-96 bg-gradient-to-b from-white to-slate-50 border-r border-gray-200/80 p-6 space-y-6 shadow-sm">
      <div className="space-y-2 mb-8">
        <div className="flex items-center gap-3">
          <div className="w-2 h-6 bg-gradient-to-b from-[#E63946] to-[#ff6b7a] rounded-full"></div>
          <h2 className="text-2xl font-bold text-gray-800">Traffic Controls</h2>
        </div>
        <p className="text-gray-600 ml-5">Simulate disruptions and test AI optimization</p>
      </div>

      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="pb-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-t-lg">
          <CardTitle className="text-xl text-[#003DA5] font-semibold flex items-center gap-3">
            <div className="w-8 h-8 bg-[#003DA5] rounded-lg flex items-center justify-center">
              <Clock className="w-4 h-4 text-white" />
            </div>
            Disruption Controls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 p-6">
          {/* Action Buttons */}
          <div className="space-y-1">
            <h3 className="text-base font-semibold text-gray-700 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <Button 
                onClick={onDelayTrain}
                className="w-full bg-gradient-to-r from-[#E63946] to-[#ff4757] hover:from-[#d32f2f] hover:to-[#E63946] text-white flex items-center gap-3 py-3 text-base font-medium shadow-md hover:shadow-lg transition-all duration-200"
              >
                <Clock className="w-5 h-5" />
                Apply Train Delay
              </Button>
              
              <Button 
                onClick={onBlockSection}
                variant="outline" 
                className="w-full border-2 border-[#E63946] text-[#E63946] hover:bg-[#E63946] hover:text-white flex items-center gap-3 py-3 text-base font-medium shadow-md hover:shadow-lg transition-all duration-200"
              >
                <Square className="w-5 h-5" />
                Block Track Section
              </Button>
              
              <Button 
                onClick={onRescheduleTrain}
                variant="outline"
                className="w-full border-2 border-[#003DA5] text-[#003DA5] hover:bg-[#003DA5] hover:text-white flex items-center gap-3 py-3 text-base font-medium shadow-md hover:shadow-lg transition-all duration-200"
              >
                <Shuffle className="w-5 h-5" />
                Reschedule Train
              </Button>
            </div>
          </div>

          {/* Selection Parameters */}
          <div className="space-y-5">
            <h3 className="text-base font-semibold text-gray-700 mb-4">Selection Parameters</h3>
            
            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                <div className="w-3 h-3 bg-[#003DA5] rounded-full"></div>
                Train Identifier
              </label>
              <Select value={selectedTrain} onValueChange={onTrainChange}>
                <SelectTrigger className="h-12 border-2 hover:border-[#003DA5] focus:border-[#003DA5] transition-colors">
                  <SelectValue placeholder="Choose train to control" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="EXP-101">EXP-101 (Mumbai Express)</SelectItem>
                  <SelectItem value="EXP-102">EXP-102 (Shatabdi Express)</SelectItem>
                  <SelectItem value="FRG-201">FRG-201 (Freight Express)</SelectItem>
                  <SelectItem value="FRG-202">FRG-202 (Cargo Special)</SelectItem>
                  <SelectItem value="LOC-301">LOC-301 (Local Passenger)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                Track Section
              </label>
              <Select value={selectedSection} onValueChange={onSectionChange}>
                <SelectTrigger className="h-12 border-2 hover:border-orange-500 focus:border-orange-500 transition-colors">
                  <SelectValue placeholder="Select track section" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A-B">Section A-B (Mumbai-Pune)</SelectItem>
                  <SelectItem value="B-C">Section B-C (Pune-Delhi)</SelectItem>
                  <SelectItem value="C-D">Section C-D (Delhi-Chennai)</SelectItem>
                  <SelectItem value="D-E">Section D-E (Chennai-Bangalore)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                Station Hub
              </label>
              <Select value={selectedStation} onValueChange={onStationChange}>
                <SelectTrigger className="h-12 border-2 hover:border-green-500 focus:border-green-500 transition-colors">
                  <SelectValue placeholder="Choose station" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mumbai Central">Mumbai Central</SelectItem>
                  <SelectItem value="Pune Junction">Pune Junction</SelectItem>
                  <SelectItem value="Delhi Junction">Delhi Junction</SelectItem>
                  <SelectItem value="Chennai Central">Chennai Central</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3 p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
              <label className="text-sm font-semibold text-gray-700 flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-[#E63946] rounded-full"></div>
                  Delay Duration
                </span>
                <span className="text-lg font-bold text-[#E63946]">{delayMinutes[0]} minutes</span>
              </label>
              <Slider
                value={delayMinutes}
                onValueChange={onDelayChange}
                max={60}
                min={0}
                step={5}
                className="w-full py-2"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>0 min</span>
                <span>30 min</span>
                <span>60 min</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}